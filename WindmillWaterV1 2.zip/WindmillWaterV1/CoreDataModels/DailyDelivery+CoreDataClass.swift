//
//  DailyDelivery+CoreDataClass.swift
//  WindmillWaterV1
//
//  Created by Derek Mora on 7/29/24.
//
//

import Foundation
import CoreData

@objc(DailyDelivery)
public class DailyDelivery: NSManagedObject {

}
