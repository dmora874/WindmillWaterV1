//
//  DefaultDelivery+CoreDataClass.swift
//  WindmillWaterV1
//
//  Created by Derek Mora on 7/27/24.
//
//

import Foundation
import CoreData

@objc(DefaultDelivery)
public class DefaultDelivery: NSManagedObject {

}
