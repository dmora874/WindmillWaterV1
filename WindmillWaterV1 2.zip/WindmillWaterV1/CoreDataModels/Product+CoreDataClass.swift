//
//  Product+CoreDataClass.swift
//  WindmillWaterV1
//
//  Created by Derek Mora on 7/23/24.
//
//

import Foundation
import CoreData

@objc(Product)
public class Product: NSManagedObject {

}
