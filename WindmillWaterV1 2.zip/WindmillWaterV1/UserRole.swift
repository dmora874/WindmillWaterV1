enum UserRole {
    case admin, deliveryManager, warehouseManager
}
